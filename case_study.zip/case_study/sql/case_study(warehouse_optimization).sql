use warehouse_optimization;
show tables;
select * from customers;
select * from postal_coordinates;



with weighted_centroid as(
select 
sum(p.lat * c.number_of_packages) / sum(c.number_of_packages) as "weighted_lat",
sum(p.lon * c.number_of_packages) / sum(c.number_of_packages) as "weighted_long"
from customers c
join postal_coordinates p
on c.postalcode_first4digits=p.postalcode_first4digits
),
warehouse_distance as(
select c.postalcode_first4digits,p.city,
sqrt(power(p.lat - wc.weighted_lat,2) + power(p.lon - wc.weighted_long,2)) as "distance"
from customers c
join postal_coordinates p
on c.postalcode_first4digits=p.postalcode_first4digits
cross join weighted_centroid wc
)
select postalcode_first4digits,city from warehouse_distance
order by distance asc
limit 1;







